CREATE TABLE `configuration_details` (
  `record_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_type` enum('session','user','group') NOT NULL DEFAULT 'session',
  `record_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  `is_set` enum('n','y') NOT NULL DEFAULT 'n',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `servername` varchar(255) NOT NULL DEFAULT '',
  `site_type` varchar(255) NOT NULL DEFAULT '',
  `release_number` int(3) unsigned NOT NULL,
  PRIMARY KEY (`record_id`),
  KEY `record` (`record_type`,`record_type_id`,`site_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2531593 DEFAULT CHARSET=latin1;

CREATE TABLE `configuration_record` (
  `record_id` int(10) unsigned NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `code` varchar(255) NOT NULL DEFAULT '',
  `active` enum('','y') NOT NULL DEFAULT '',
  `link_id` int(10) unsigned DEFAULT NULL,
  `link_code` varchar(255) DEFAULT NULL,
  `data` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`record_id`),
  KEY `code_type` (`type`,`code`),
  KEY `active_config` (`type`,`code`,`active`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `configuration_set` (
  `set_id` int(10) unsigned NOT NULL,
  `record_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`set_id`,`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `group_member` (
  `group_member_id` int(11) NOT NULL AUTO_INCREMENT,
  `webgroup_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `level` enum('member','administrator') NOT NULL DEFAULT 'member',
  `status` enum('active','inactive','pending','barred') NOT NULL DEFAULT 'active',
  `member_status` enum('active','inactive','pending','barred') NOT NULL DEFAULT 'inactive',
  `data` text,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`group_member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38055 DEFAULT CHARSET=latin1;

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `identity` varchar(255) DEFAULT NULL,
  `type` enum('local','openid','ldap') NOT NULL DEFAULT 'local',
  `data` text,
  `status` enum('active','pending') NOT NULL DEFAULT 'pending',
  `salt` varchar(8) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`login_id`),
  KEY `identityx` (`identity`),
  KEY `user_idx` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26325 DEFAULT CHARSET=latin1;

CREATE TABLE `old_schema_group_member` (
  `group_member_id` int(11) NOT NULL AUTO_INCREMENT,
  `webgroup_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `level` enum('member','administrator','superuser') NOT NULL DEFAULT 'member',
  `status` enum('active','inactive','pending','barred') NOT NULL DEFAULT 'active',
  `member_status` enum('active','inactive','pending','barred') DEFAULT 'inactive',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=459 DEFAULT CHARSET=latin1;

CREATE TABLE `old_schema_group_record` (
  `group_record_id` int(11) NOT NULL AUTO_INCREMENT,
  `webgroup_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`group_record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=611 DEFAULT CHARSET=latin1;

CREATE TABLE `old_schema_group_record_vega` (
  `group_record_vega_id` int(11) NOT NULL AUTO_INCREMENT,
  `webgroup_id` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`group_record_vega_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

CREATE TABLE `old_schema_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `salt` varchar(8) NOT NULL DEFAULT '',
  `password` varchar(64) DEFAULT '',
  `data` text,
  `organisation` text,
  `status` enum('active','pending','suspended') NOT NULL DEFAULT 'pending',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106945 DEFAULT CHARSET=latin1;

CREATE TABLE `old_schema_user_record` (
  `user_record_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=147254 DEFAULT CHARSET=latin1;

CREATE TABLE `old_schema_user_record_vega` (
  `user_record_vega_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_record_vega_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3229 DEFAULT CHARSET=latin1;

CREATE TABLE `old_schema_webgroup` (
  `webgroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `blurb` text NOT NULL,
  `data` text NOT NULL,
  `type` enum('open','restricted','private') NOT NULL DEFAULT 'open',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`webgroup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=latin1;

CREATE TABLE `record` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `record_type` enum('user','group') NOT NULL DEFAULT 'user',
  `record_type_id` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `data` text,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`record_id`),
  KEY `record_type_idx` (`record_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=167253 DEFAULT CHARSET=latin1;

CREATE TABLE `record_vega` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `record_type` enum('user','group') NOT NULL DEFAULT 'user',
  `record_type_id` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `data` text,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`record_id`),
  KEY `record_type_idx` (`record_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=849 DEFAULT CHARSET=latin1;

CREATE TABLE `session` (
  `last_session_no` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `session_record` (
  `session_record_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL DEFAULT '',
  `code` varchar(240) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `valid_thru` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`session_record_id`),
  UNIQUE KEY `session_id` (`session_id`,`code`,`type`(1)),
  KEY `code_type` (`type`(1),`code`)
) ENGINE=InnoDB AUTO_INCREMENT=10625305 DEFAULT CHARSET=latin1;

CREATE TABLE `sessions` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `a_session` mediumtext NOT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `modified_at` (`modified_at`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `share_url` (
  `code` varchar(64) NOT NULL,
  `url` text NOT NULL,
  `type` varchar(32) NOT NULL,
  `action` varchar(32) NOT NULL,
  `data` text NOT NULL,
  `share_type` varchar(10) NOT NULL,
  `used` int(10) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `type` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`type_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `data` text,
  `organisation` varchar(255) DEFAULT NULL,
  `country` varchar(2) DEFAULT NULL,
  `status` enum('active','suspended') NOT NULL DEFAULT 'active',
  `salt` varchar(8) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=117779 DEFAULT CHARSET=latin1;

CREATE TABLE `user_admin` (
  `user_admin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_admin_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `webgroup` (
  `webgroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `blurb` text,
  `data` text,
  `type` enum('open','restricted','private','hidden') DEFAULT 'restricted',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`webgroup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=latin1;

